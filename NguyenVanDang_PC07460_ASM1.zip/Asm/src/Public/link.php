<link href="https://ap.poly.edu.vn/theme/student_v2/vendors/custom/fullcalendar/fullcalendar.bundle.css" rel="stylesheet" type="text/css" />
<link href="https://ap.poly.edu.vn/theme/student_v2/vendors/global/vendors.bundle.css" rel="stylesheet" type="text/css" />
<link href="https://ap.poly.edu.vn/theme/student_v2/css/demo1/style.bundle.css" rel="stylesheet" type="text/css" />
<link href="https://ap.poly.edu.vn/theme/student_v2/css/demo1/skins/header/base/light.css" rel="stylesheet" type="text/css" />
<link href="https://ap.poly.edu.vn/theme/student_v2/css/demo1/skins/header/menu/light.css" rel="stylesheet" type="text/css" />
<link href="https://ap.poly.edu.vn/theme/student_v2/css/demo1/skins/brand/light.css" rel="stylesheet" type="text/css" />
<link href="https://ap.poly.edu.vn/theme/student_v2/css/demo1/skins/aside/light.css" rel="stylesheet" type="text/css" />
<link href="https://ap.poly.edu.vn/theme/student_v2/vendors/custom/datatables/datatables.bundle.css" rel="stylesheet" type="text/css" />
<link href="https://ap.poly.edu.vn/css/web.css" rel="stylesheet" />
<link href="https://ap.poly.edu.vn/css/popup.css" id="theme" rel="stylesheet" />
<!-- login -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- home -->
<script src="https://ap.poly.edu.vn/theme/student_v2/vendors/global/vendors.bundle.js" type="text/javascript"></script>
<script src="https://ap.poly.edu.vn/theme/student_v2/js/demo1/scripts.bundle.js" type="text/javascript"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<!-- cssuer-->
<link rel="stylesheet" href="/Asm/src/Public/css/login.css">
<link rel="stylesheet" href="/Asm/src/Public/css/style.css">

