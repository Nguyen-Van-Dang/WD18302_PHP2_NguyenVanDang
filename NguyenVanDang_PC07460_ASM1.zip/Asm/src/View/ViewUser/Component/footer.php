<div id="kt_footer" class="kt-footer kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop">
    <div class="kt-container kt-container--fluid">
        <div class="footer-filter-by-campus" style="display: flex; flex-direction: column;justify-items: center;align-items: center; margin: 0 auto;">
            <img id="poly-logo" src="src/Public/img/logo.png" width="250" />
            <h6 class="kt-widget1__title">
                <a class="kt-link address">
                    Số 288, Nguyễn Văn Linh, phường An Khánh, quận Ninh
                    Kiều, Tp. Cần Thơ.
                </a>
            </h6>
        </div>
    </div>
</div>