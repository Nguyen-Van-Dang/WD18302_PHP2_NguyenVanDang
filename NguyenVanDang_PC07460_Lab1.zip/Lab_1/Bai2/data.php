<?
$course = [
    'Sinh' => 'Sinh Học',
    'Sử' => 'Lịch Sử',
    'Địa' => 'Địa Lý',
    'Toán' => 'Toán',
    'Lý' => 'Vật Lý',
    'Hóa' => 'Hóa Học'
];
?>