<?
//controller
include 'model.php';
$user = display_user();

include 'view.php';
?>
